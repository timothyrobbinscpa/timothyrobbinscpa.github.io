# Project Overview

Recommendation systems are a important application of machine learning that aim to provide personalized suggestions to users for products, services, or content they might be interested in. A movie recommendation system is a type of information filterting system used to predict and display movies that a user is likely to enjoy, based on past behavior, preferences, and/or demographic information.  Such systems are widely used on streaming platforms, e-commerce sites, and other online services with  the intention of maximizing the user experience.

There are 3 main types of Recommendation Systems:
 - Collaborative Filtering: This method makes a prediction about the interests of a user by collecting preferences from many other users.  There are two main types of collaborative filtering:
    - User-Based: Recommends movies by finding other users with similar tastes and preferences.
    - Item-Based: Recommends movies by comparing the similarities between different movies.
 - Content-Based Filtering: This method recommends movies by using features of the movie (such as genre, cast, director) and suggests similar movies based on a user's past preferences.
 - Hybrid Recommendation: This method combines both collaborative and content-based filtering.

This project focuses on a hybrid model, which merges the detailed analysis offered by content-based filtering with the broader perspective provided by collaborative filtering. Users are prompted to specify their favorite movie periods and genres, implementing content-based filtering. This is further refined through user ratings on a selection of movies, incorporating collaborative filtering aspects. By adopting this hybrid approach, my aim is to enhance the precision of the recommendations and significantly improve the overall user experience, taking into account the varied and evolving nature of movie preferences.

## Datasets

This project utilizes the MovieLens dataset, a widely used dataset in the field of recommender systems, containing movie ratings and metadata.  The data was obtained at https://www.kaggle.com/datasets/parasharmanas/movie-recommendation-system/data.  There are two data files. The first contains the unique movie Id, movie title and a list of genres the movie falls into.  The second consists of user ratings with the user ID, movie ID, rating and timestap of when the review was made.

## Import Libraries and Read Data


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

plt.style.use('ggplot')
```


```python
movies_df = pd.read_csv('../data/movies.csv')

movies_df.shape
```




    (9742, 3)




```python
ratings_df = pd.read_csv('../data/ratings.csv')

ratings_df.shape
```




    (100836, 4)



# Initial EDA

## Data Overview


```python
movies_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>movieId</th>
      <th>title</th>
      <th>genres</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>Adventure|Animation|Children|Comedy|Fantasy</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Jumanji (1995)</td>
      <td>Adventure|Children|Fantasy</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Grumpier Old Men (1995)</td>
      <td>Comedy|Romance</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Waiting to Exhale (1995)</td>
      <td>Comedy|Drama|Romance</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Father of the Bride Part II (1995)</td>
      <td>Comedy</td>
    </tr>
  </tbody>
</table>
</div>




```python
movies_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 9742 entries, 0 to 9741
    Data columns (total 3 columns):
     #   Column   Non-Null Count  Dtype 
    ---  ------   --------------  ----- 
     0   movieId  9742 non-null   int64 
     1   title    9742 non-null   object
     2   genres   9742 non-null   object
    dtypes: int64(1), object(2)
    memory usage: 228.5+ KB
    


```python
movies_df.describe(include='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>movieId</th>
      <th>title</th>
      <th>genres</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>9742.000000</td>
      <td>9742</td>
      <td>9742</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>NaN</td>
      <td>9737</td>
      <td>951</td>
    </tr>
    <tr>
      <th>top</th>
      <td>NaN</td>
      <td>Emma (1996)</td>
      <td>Drama</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>NaN</td>
      <td>2</td>
      <td>1053</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>42200.353623</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>std</th>
      <td>52160.494854</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>3248.250000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>7300.000000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>76232.000000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>max</th>
      <td>193609.000000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



Movies Dataframe Summary:
- There are 9,742 unique movies.
- The genres column has 951 unique genre combinations, with 'Drama' being the most frequent.  The number of genres does not appear resaonable, so will conduct further analysis on.
- The movieId ranges from 1 to 193,609, indicating a broad and possibly sparse numbering system, as there are only 9,737 unique movie titles.


```python
movies_df.isna().sum()
```




    movieId    0
    title      0
    genres     0
    dtype: int64



There are no missing values in the movies dataset.


```python
movies_df.duplicated().sum()
```




    0



There are no duplicate rows in the movies dataset.


```python
ratings_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 100836 entries, 0 to 100835
    Data columns (total 4 columns):
     #   Column     Non-Null Count   Dtype  
    ---  ------     --------------   -----  
     0   userId     100836 non-null  int64  
     1   movieId    100836 non-null  int64  
     2   rating     100836 non-null  float64
     3   timestamp  100836 non-null  int64  
    dtypes: float64(1), int64(3)
    memory usage: 3.1 MB
    


```python
ratings_df.describe(include='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>userId</th>
      <th>movieId</th>
      <th>rating</th>
      <th>timestamp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>100836.000000</td>
      <td>100836.000000</td>
      <td>100836.000000</td>
      <td>1.008360e+05</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>326.127564</td>
      <td>19435.295718</td>
      <td>3.501557</td>
      <td>1.205946e+09</td>
    </tr>
    <tr>
      <th>std</th>
      <td>182.618491</td>
      <td>35530.987199</td>
      <td>1.042529</td>
      <td>2.162610e+08</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.500000</td>
      <td>8.281246e+08</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>177.000000</td>
      <td>1199.000000</td>
      <td>3.000000</td>
      <td>1.019124e+09</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>325.000000</td>
      <td>2991.000000</td>
      <td>3.500000</td>
      <td>1.186087e+09</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>477.000000</td>
      <td>8122.000000</td>
      <td>4.000000</td>
      <td>1.435994e+09</td>
    </tr>
    <tr>
      <th>max</th>
      <td>610.000000</td>
      <td>193609.000000</td>
      <td>5.000000</td>
      <td>1.537799e+09</td>
    </tr>
  </tbody>
</table>
</div>



Ratings Dataframe Summary:
- Contains 100,836 ratings.
- userId ranges from 1 to 610, indicating 610 unique users.
- Ratings range from 0.5 to 5.0, in increments of 0.5.
- The average rating is approximately 3.50.
- timestamp is an integer representing the time the user rating was made.

I will now merge the two datasets which will allow us to see which user rated which movie, along with the movie's title and genres.


```python
# Merge the two df's pn movieId
df = movies_df.merge(ratings_df, on='movieId')

df.shape
```




    (100836, 6)




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>movieId</th>
      <th>title</th>
      <th>genres</th>
      <th>userId</th>
      <th>rating</th>
      <th>timestamp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>Adventure|Animation|Children|Comedy|Fantasy</td>
      <td>1</td>
      <td>4.0</td>
      <td>964982703</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>Adventure|Animation|Children|Comedy|Fantasy</td>
      <td>5</td>
      <td>4.0</td>
      <td>847434962</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>Adventure|Animation|Children|Comedy|Fantasy</td>
      <td>7</td>
      <td>4.5</td>
      <td>1106635946</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>Adventure|Animation|Children|Comedy|Fantasy</td>
      <td>15</td>
      <td>2.5</td>
      <td>1510577970</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>Adventure|Animation|Children|Comedy|Fantasy</td>
      <td>17</td>
      <td>4.5</td>
      <td>1305696483</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 100836 entries, 0 to 100835
    Data columns (total 6 columns):
     #   Column     Non-Null Count   Dtype  
    ---  ------     --------------   -----  
     0   movieId    100836 non-null  int64  
     1   title      100836 non-null  object 
     2   genres     100836 non-null  object 
     3   userId     100836 non-null  int64  
     4   rating     100836 non-null  float64
     5   timestamp  100836 non-null  int64  
    dtypes: float64(1), int64(3), object(2)
    memory usage: 4.6+ MB
    


```python
df.describe(include='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>movieId</th>
      <th>title</th>
      <th>genres</th>
      <th>userId</th>
      <th>rating</th>
      <th>timestamp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>100836.000000</td>
      <td>100836</td>
      <td>100836</td>
      <td>100836.000000</td>
      <td>100836.000000</td>
      <td>1.008360e+05</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>NaN</td>
      <td>9719</td>
      <td>951</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>NaN</td>
      <td>Forrest Gump (1994)</td>
      <td>Comedy</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>NaN</td>
      <td>329</td>
      <td>7196</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>19435.295718</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>326.127564</td>
      <td>3.501557</td>
      <td>1.205946e+09</td>
    </tr>
    <tr>
      <th>std</th>
      <td>35530.987199</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>182.618491</td>
      <td>1.042529</td>
      <td>2.162610e+08</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>0.500000</td>
      <td>8.281246e+08</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1199.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>177.000000</td>
      <td>3.000000</td>
      <td>1.019124e+09</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2991.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>325.000000</td>
      <td>3.500000</td>
      <td>1.186087e+09</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>8122.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>477.000000</td>
      <td>4.000000</td>
      <td>1.435994e+09</td>
    </tr>
    <tr>
      <th>max</th>
      <td>193609.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>610.000000</td>
      <td>5.000000</td>
      <td>1.537799e+09</td>
    </tr>
  </tbody>
</table>
</div>



Combined Dataset Statistics:
- The dataset contains 100,836 ratings for 9,719 unique movies.
- The genres column has 951 unique genre combinations, with 'Comedy' being the most frequent.
- Ratings range from 0.5 to 5.0, with an average of approximately 3.50.


```python
df.isna().sum()
```




    movieId      0
    title        0
    genres       0
    userId       0
    rating       0
    timestamp    0
    dtype: int64



There are no missing values in the combined dataset


```python
# Plot ratings distribution
plt.figure(figsize=(10, 6))
sns.countplot(x='rating', hue='rating', data=df, legend=False, palette='muted')
plt.title('Distribution of Ratings')
plt.xlabel('Rating')
plt.ylabel('Count')
plt.show()

```


    
![png](output_29_0.png)
    


The distribution of ratings shows that:
- Ratings are discrete, in increments of 0.5.
- The most common ratings are around 3.0 to 4.0, indicating a tendency towards higher ratings.
- The extreme ratings (0.5 and 5.0) are less common, suggesting that users are generally moderate in their assessments.


```python
df['genres']
```




    0         Adventure|Animation|Children|Comedy|Fantasy
    1         Adventure|Animation|Children|Comedy|Fantasy
    2         Adventure|Animation|Children|Comedy|Fantasy
    3         Adventure|Animation|Children|Comedy|Fantasy
    4         Adventure|Animation|Children|Comedy|Fantasy
                                 ...                     
    100831                Action|Animation|Comedy|Fantasy
    100832                       Animation|Comedy|Fantasy
    100833                                          Drama
    100834                               Action|Animation
    100835                                         Comedy
    Name: genres, Length: 100836, dtype: object




```python
# split genres by | and add as a list
df['genres'] = df['genres'].apply(lambda x:x.split('|'))
                                  
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>movieId</th>
      <th>title</th>
      <th>genres</th>
      <th>userId</th>
      <th>rating</th>
      <th>timestamp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>1</td>
      <td>4.0</td>
      <td>964982703</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>5</td>
      <td>4.0</td>
      <td>847434962</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>7</td>
      <td>4.5</td>
      <td>1106635946</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>15</td>
      <td>2.5</td>
      <td>1510577970</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>17</td>
      <td>4.5</td>
      <td>1305696483</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['genres']
```




    0         [Adventure, Animation, Children, Comedy, Fantasy]
    1         [Adventure, Animation, Children, Comedy, Fantasy]
    2         [Adventure, Animation, Children, Comedy, Fantasy]
    3         [Adventure, Animation, Children, Comedy, Fantasy]
    4         [Adventure, Animation, Children, Comedy, Fantasy]
                                    ...                        
    100831                 [Action, Animation, Comedy, Fantasy]
    100832                         [Animation, Comedy, Fantasy]
    100833                                              [Drama]
    100834                                  [Action, Animation]
    100835                                             [Comedy]
    Name: genres, Length: 100836, dtype: object




```python
# Break out genres included in list and determine count of each
import matplotlib.pyplot as plt

# Explode the genres column to have separate row for each genre
exploded_genres = df.explode('genres')

# Count the occurrences of each genre
genre_counts = exploded_genres['genres'].value_counts()
genre_counts
```




    genres
    Drama                 41928
    Comedy                39053
    Action                30635
    Thriller              26452
    Adventure             24161
    Romance               18124
    Sci-Fi                17243
    Crime                 16681
    Fantasy               11834
    Children               9208
    Mystery                7674
    Horror                 7291
    Animation              6988
    War                    4859
    IMAX                   4145
    Musical                4138
    Western                1930
    Documentary            1219
    Film-Noir               870
    (no genres listed)       47
    Name: count, dtype: int64




```python
# Plot the genre frequencies

g = sns.catplot(genre_counts, kind='bar', palette='muted', height=5, aspect=2)
g.fig.suptitle('Frequency of Movie Genres')
plt.xlabel('Genre')
plt.ylabel('Number of Movies')
plt.xticks(rotation=45)
plt.show()
```

    C:\Users\trobb\AppData\Local\Temp\ipykernel_23812\1897979922.py:3: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      g = sns.catplot(genre_counts, kind='bar', palette='muted', height=5, aspect=2)
    


    
![png](output_35_1.png)
    


Drama and Comedy are the most common genres, followed by Action, Thriller, and Adventure.


```python
# MOVE TO PREPROCESSING
# Extract year of movie from title

# Regular expression to match a year in parentheses at the end of the title
pattern = r'\((\d{4})\)$'

# Extract the year and create a new column
df['movie_year'] = df['title'].str.extract(pattern, expand=False)

# Optionally, remove the year from the title
df['title'] = df['title'].str.replace(pattern, '').str.strip()

df.head()

df['movie_year'] = df['movie_year'].astype(float)
```


```python

```


```python
df.dtypes
```




    movieId         int64
    title          object
    genres         object
    userId          int64
    rating        float64
    timestamp       int64
    movie_year    float64
    dtype: object




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>movieId</th>
      <th>title</th>
      <th>genres</th>
      <th>userId</th>
      <th>rating</th>
      <th>timestamp</th>
      <th>movie_year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>1</td>
      <td>4.0</td>
      <td>964982703</td>
      <td>1995.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>5</td>
      <td>4.0</td>
      <td>847434962</td>
      <td>1995.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>7</td>
      <td>4.5</td>
      <td>1106635946</td>
      <td>1995.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>15</td>
      <td>2.5</td>
      <td>1510577970</td>
      <td>1995.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>17</td>
      <td>4.5</td>
      <td>1305696483</td>
      <td>1995.0</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
import pandas as pd

# Load your DataFrame (assuming it's already loaded as df)
# df = pd.read_csv('your_data.csv')

# Convert the 'timestamp' column to datetime
df['date'] = pd.to_datetime(df['timestamp'], unit='s')

# Display the first few rows to verify the conversion
print(df.head())

```

       movieId             title  \
    0        1  Toy Story (1995)   
    1        1  Toy Story (1995)   
    2        1  Toy Story (1995)   
    3        1  Toy Story (1995)   
    4        1  Toy Story (1995)   
    
                                                  genres  userId  rating  \
    0  [Adventure, Animation, Children, Comedy, Fantasy]       1     4.0   
    1  [Adventure, Animation, Children, Comedy, Fantasy]       5     4.0   
    2  [Adventure, Animation, Children, Comedy, Fantasy]       7     4.5   
    3  [Adventure, Animation, Children, Comedy, Fantasy]      15     2.5   
    4  [Adventure, Animation, Children, Comedy, Fantasy]      17     4.5   
    
        timestamp  movie_year                date  
    0   964982703      1995.0 2000-07-30 18:45:03  
    1   847434962      1995.0 1996-11-08 06:36:02  
    2  1106635946      1995.0 2005-01-25 06:52:26  
    3  1510577970      1995.0 2017-11-13 12:59:30  
    4  1305696483      1995.0 2011-05-18 05:28:03  
    


```python
df[df['rating'] > 4.5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>movieId</th>
      <th>title</th>
      <th>genres</th>
      <th>userId</th>
      <th>rating</th>
      <th>timestamp</th>
      <th>movie_year</th>
      <th>date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>9</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>31</td>
      <td>5.0</td>
      <td>850466616</td>
      <td>1995.0</td>
      <td>1996-12-13 08:43:36</td>
    </tr>
    <tr>
      <th>12</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>40</td>
      <td>5.0</td>
      <td>832058959</td>
      <td>1995.0</td>
      <td>1996-05-14 07:29:19</td>
    </tr>
    <tr>
      <th>13</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>43</td>
      <td>5.0</td>
      <td>848993983</td>
      <td>1995.0</td>
      <td>1996-11-26 07:39:43</td>
    </tr>
    <tr>
      <th>16</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>46</td>
      <td>5.0</td>
      <td>834787906</td>
      <td>1995.0</td>
      <td>1996-06-14 21:31:46</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1</td>
      <td>Toy Story (1995)</td>
      <td>[Adventure, Animation, Children, Comedy, Fantasy]</td>
      <td>57</td>
      <td>5.0</td>
      <td>965796031</td>
      <td>1995.0</td>
      <td>2000-08-09 04:40:31</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>100787</th>
      <td>187593</td>
      <td>Deadpool 2 (2018)</td>
      <td>[Action, Comedy, Sci-Fi]</td>
      <td>98</td>
      <td>5.0</td>
      <td>1532457913</td>
      <td>2018.0</td>
      <td>2018-07-24 18:45:13</td>
    </tr>
    <tr>
      <th>100790</th>
      <td>187593</td>
      <td>Deadpool 2 (2018)</td>
      <td>[Action, Comedy, Sci-Fi]</td>
      <td>249</td>
      <td>5.0</td>
      <td>1531611534</td>
      <td>2018.0</td>
      <td>2018-07-14 23:38:54</td>
    </tr>
    <tr>
      <th>100791</th>
      <td>187593</td>
      <td>Deadpool 2 (2018)</td>
      <td>[Action, Comedy, Sci-Fi]</td>
      <td>305</td>
      <td>5.0</td>
      <td>1532877841</td>
      <td>2018.0</td>
      <td>2018-07-29 15:24:01</td>
    </tr>
    <tr>
      <th>100801</th>
      <td>187595</td>
      <td>Solo: A Star Wars Story (2018)</td>
      <td>[Action, Adventure, Children, Sci-Fi]</td>
      <td>586</td>
      <td>5.0</td>
      <td>1529899556</td>
      <td>2018.0</td>
      <td>2018-06-25 04:05:56</td>
    </tr>
    <tr>
      <th>100802</th>
      <td>187717</td>
      <td>Won't You Be My Neighbor? (2018)</td>
      <td>[Documentary]</td>
      <td>462</td>
      <td>5.0</td>
      <td>1529413865</td>
      <td>2018.0</td>
      <td>2018-06-19 13:11:05</td>
    </tr>
  </tbody>
</table>
<p>13211 rows × 8 columns</p>
</div>




```python

```

# Movie Recommendations


```python
from sklearn.metrics.pairwise import cosine_similarity

# Creating the user-item matrix. Rows will be userIds, columns will be movie titles, and values will be ratings
user_item_matrix = df.pivot_table(index='userId', columns='title', values='rating')

# Replacing NaN values with 0, as we'll calculate cosine similarity
user_item_matrix_filled = user_item_matrix.fillna(0)

# Calculate the cosine similarity matrix (item-item similarity)
item_similarity = cosine_similarity(user_item_matrix_filled.T)  # Transpose to get item-item matrix

# Converting the numpy matrix to a DataFrame for better readability
item_similarity_df = pd.DataFrame(item_similarity, index=user_item_matrix_filled.columns, columns=user_item_matrix_filled.columns)

# Displaying a portion of the similarity matrix
item_similarity_df.iloc[:5, :5]  # Displaying first 5x5 block for brevity
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>title</th>
      <th>'71 (2014)</th>
      <th>'Hellboy': The Seeds of Creation (2004)</th>
      <th>'Round Midnight (1986)</th>
      <th>'Salem's Lot (2004)</th>
      <th>'Til There Was You (1997)</th>
    </tr>
    <tr>
      <th>title</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>'71 (2014)</th>
      <td>1.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>'Hellboy': The Seeds of Creation (2004)</th>
      <td>0.0</td>
      <td>1.000000</td>
      <td>0.707107</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>'Round Midnight (1986)</th>
      <td>0.0</td>
      <td>0.707107</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>'Salem's Lot (2004)</th>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.857493</td>
    </tr>
    <tr>
      <th>'Til There Was You (1997)</th>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.857493</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
import random


def get_user_preferences(movies_df):
    # Get movie period preferences
    start_year = int(input("Enter the start year of your preferred movie period: "))
    end_year = int(input("Enter the end year of your preferred movie period: "))

    # Get genre preferences
    print("Please enter your top 3 favorite genres from the following list:")
    all_genres = set(genre for genre_list in movies_df['genres'].str.split('|') for genre in genre_list)
    print(', '.join(sorted(all_genres)))

    top_genres = []
    while len(top_genres) < 3:
        genre = input(f"Enter genre {len(top_genres) + 1}: ").strip()
        if genre in all_genres and genre not in top_genres:
            top_genres.append(genre)
        else:
            print("Invalid genre or duplicate entry. Please try again.")
    
    return start_year, end_year, top_genres

def get_user_ratings(filtered_movies, min_ratings=5):
    print("\nPlease rate at least 5 movies on a scale from 1 to 5. If you haven't seen a movie, just press Enter.")

    sampled_movies = filtered_movies['title'].sample(n=min(len(filtered_movies), min_ratings * 10)).tolist()

    ratings = {}
    while len(ratings) < min_ratings:
        for movie in sampled_movies:
            if movie in ratings:
                continue  # Skip already rated movies

            rating_input = input(f"Rating for '{movie}': ").strip()

            if rating_input == '':
                continue  # Skip unrated movies

            try:
                rating = float(rating_input)
                if 1 <= rating <= 5:
                    ratings[movie] = rating
                else:
                    print("Please enter a number between 1 and 5.")
            except ValueError:
                print("Invalid input. Please enter a valid number or press Enter to skip.")

            if len(ratings) >= min_ratings:
                return ratings

        # Re-sample additional movies if needed
        additional_movies = filtered_movies[~filtered_movies['title'].isin(sampled_movies)]['title'].sample(
            n=min(len(filtered_movies) - len(sampled_movies), min_ratings)).tolist()
        sampled_movies.extend(additional_movies)

    return ratings

# Extract year from the movie title
movies_df['year'] = movies_df['title'].str.extract(r'\((\d{4})\)').astype(float)

# Get user preferences
start_year, end_year, top_genres = get_user_preferences(movies_df)

# Filter movies based on year range and genres
filtered_movies = movies_df[
    (movies_df['year'].between(start_year, end_year)) &
    (movies_df['genres'].str.contains('|'.join(top_genres)))
]

# Get user ratings
user_ratings = get_user_ratings(filtered_movies)
print("\nYour ratings:")
for movie, rating in user_ratings.items():
    print(f"{movie}: {rating}")
    
    
def make_recommendations(user_ratings, item_similarity_df, num_recommendations=5):
    # Convert user_ratings to a Series for easier processing
    user_ratings_series = pd.Series(user_ratings)
    
    # Initialize a Series to store the total weighted similarity score of each movie
    total_scores = pd.Series(dtype='float64')

    # Iterate through movies rated by the user and calculate weighted scores
    for movie, rating in user_ratings_series.items():
        # Skip if the movie is not in the similarity matrix
        if movie not in item_similarity_df.columns:
            continue

        # Get similarity scores for the movie
        sim_scores = item_similarity_df[movie]

        # Weighted similarity scores
        weighted_scores = sim_scores * rating

        # Add to the total scores, summing up the weights
        total_scores = total_scores.add(weighted_scores, fill_value=0)

    # Remove movies the user has already rated
    total_scores = total_scores.drop(user_ratings.keys(), errors='ignore')

    # Get top recommendations
    top_recommendations = total_scores.sort_values(ascending=False).head(num_recommendations).index.tolist()

    return top_recommendations

# Example usage
# Assuming 'item_similarity_df' is your precomputed item-item similarity matrix
# and 'user_ratings' is a dictionary containing user's movie ratings
recommended_movies = make_recommendations(user_ratings, item_similarity_df, 5)
print("\nRecommended Movies:")
for movie in recommended_movies:
    print(movie)


```

    Enter the start year of your preferred movie period:  1995
    Enter the end year of your preferred movie period:  2005
    

    Please enter your top 3 favorite genres from the following list:
    (no genres listed), Action, Adventure, Animation, Children, Comedy, Crime, Documentary, Drama, Fantasy, Film-Noir, Horror, IMAX, Musical, Mystery, Romance, Sci-Fi, Thriller, War, Western
    

    Enter genre 1:  drama
    

    Invalid genre or duplicate entry. Please try again.
    

    Enter genre 1:  Drama
    Enter genre 2:  Romance
    Enter genre 3:  Sci-Fi
    

    
    Please rate at least 5 movies on a scale from 1 to 5. If you haven't seen a movie, just press Enter.
    

    Rating for 'Rabbit-Proof Fence (2002)':  
    Rating for 'Plunkett & MaCleane (1999)':  
    Rating for 'Mondays in the Sun (Lunes al sol, Los) (2002)':  
    Rating for 'All the Real Girls (2003)':  
    Rating for 'Legend of 1900, The (a.k.a. The Legend of the Pianist on the Ocean) (Leggenda del pianista sull'oceano) (1998)':  
    Rating for 'Deep Rising (1998)':  3.5
    Rating for '28 Days Later (2002)':  3
    Rating for 'Vampire Hunter D: Bloodlust (Banpaia hantâ D) (2000)':  
    Rating for 'American President, The (1995)':  
    Rating for 'Sunshine State (2002)':  
    Rating for 'We Were Soldiers (2002)':  3.5
    Rating for 'Girl with a Pearl Earring (2003)':  
    Rating for 'Celebration, The (Festen) (1998)':  
    Rating for 'Bossa Nova (2000)':  
    Rating for 'Joe Dirt (2001)':  
    Rating for 'Three to Tango (1999)':  
    Rating for 'Event Horizon (1997)':  4
    Rating for 'Sweet Sixteen (2002)':  
    Rating for 'Englishman Who Went Up a Hill But Came Down a Mountain, The (1995)':  
    Rating for 'Chicago (2002)':  3.5
    

    
    Your ratings:
    Deep Rising (1998): 3.5
    28 Days Later (2002): 3.0
    We Were Soldiers (2002): 3.5
    Event Horizon (1997): 4.0
    Chicago (2002): 3.5
    
    Recommended Movies:
    Signs (2002)
    Equilibrium (2002)
    Pitch Black (2000)
    Blade II (2002)
    Poltergeist (1982)
    




```python

```


```python

```


```python

```
